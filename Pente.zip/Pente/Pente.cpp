/* 
* Pente main program.
*/

#include "stdafx.h"
#include "Interface.h"
#include "Tournament.h"


int main(int argc, char* argv[]) {

	
	Tournament T;

	T.run();


	return 0;
}