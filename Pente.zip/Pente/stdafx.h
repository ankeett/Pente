#pragma once

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <cctype>
#include <vector>



using namespace std;
